package com.mngmt.inventorySystem.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.mngmt.inventorySystem.dtos.ProductDTO;
import com.mngmt.inventorySystem.dtos.Response;
import com.mngmt.inventorySystem.services.ProductService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j

@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    @PostMapping
    public ResponseEntity<Response> saveProduct(@RequestPart("product") ProductDTO productDTO,
                                                @RequestPart("image") MultipartFile imageFile) {
        Response response = productService.saveProduct(productDTO, imageFile);
        return ResponseEntity.status(response.getStatus()).body(response);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Response> updateProduct(@PathVariable Long id,
                                                  @RequestPart("product") ProductDTO productDTO,
                                                  @RequestPart("image") MultipartFile imageFile) {
        productDTO.setProductId(id);
        Response response = productService.updateProduct(productDTO, imageFile);
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    @GetMapping
    public ResponseEntity<Response> getAllProducts() {
        Response response = productService.getAllProducts();
        return ResponseEntity.status(response.getStatus()).body(response);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Response> getProductById(@PathVariable String id) {
        if ("all".equalsIgnoreCase(id)) {
            return getAllProducts();
        }
        try {
            Long productId = Long.parseLong(id);
            Response response = productService.getProductById(productId);
            return ResponseEntity.status(response.getStatus()).body(response);
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body(Response.builder()
                    .status(400)
                    .message("Invalid product ID")
                    .build());
        }
    }


//    @GetMapping("/{id}")
//    public ResponseEntity<Response> getProductById(@PathVariable Long id) {
//        Response response = productService.getProductById(id);
//        return ResponseEntity.status(response.getStatus()).body(response);
//    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Response> deleteProduct(@PathVariable Long id) {
        Response response = productService.deleteProduct(id);
        return ResponseEntity.status(response.getStatus()).body(response);
    }
}

//package com.mngmt.inventorySystem.controllers;
//
//
//import com.mngmt.inventorySystem.dtos.ProductDTO;
//import com.mngmt.inventorySystem.dtos.Response;
//import com.mngmt.inventorySystem.services.EbayService;
//import com.mngmt.inventorySystem.services.ProductService;
//
//import lombok.RequiredArgsConstructor;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/products")
//@RequiredArgsConstructor
//public class ProductController {
//
//    private final ProductService productService;
//
////   @Autowired
////   private EbayService ebayService;
//
//
//    @PostMapping("/add")
//    @PreAuthorize("hasAuthority('ADMIN')")
//    public ResponseEntity<Response> saveProduct(
//            @RequestParam("imageFile") MultipartFile imageFile,
//            @RequestParam("name") String name,
//            @RequestParam("sku") String sku,
//            @RequestParam("price") BigDecimal price,
//            @RequestParam("stockQuantity") Integer stockQuantity,
//            @RequestParam("categoryId") Long categoryId,
//            @RequestParam(value = "description", required = false) String description
//    ) {
//        ProductDTO productDTO = new ProductDTO();
//        productDTO.setName(name);
//        productDTO.setSku(sku);
//        productDTO.setPrice(price);
//        productDTO.setStockQuantity(stockQuantity);
//        productDTO.setCategoryId(categoryId);
//        productDTO.setDescription(description);
//
//        return ResponseEntity.ok(productService.saveProduct(productDTO, imageFile));
//
//    }
//
//    @PutMapping("/update")
//    @PreAuthorize("hasAuthority('ADMIN')")
//    public ResponseEntity<Response> updateProduct(
//            @RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
//            @RequestParam(value = "name", required = false) String name,
//            @RequestParam(value = "sku", required = false) String sku,
//            @RequestParam(value = "price", required = false) BigDecimal price,
//            @RequestParam(value = "stockQuantity", required = false) Integer stockQuantity,
//            @RequestParam(value = "categoryId", required = false) Long categoryId,
//            @RequestParam(value = "description", required = false) String description,
//            @RequestParam("productId") Long productId
//    ) {
//        ProductDTO productDTO = new ProductDTO();
//        productDTO.setName(name);
//        productDTO.setSku(sku);
//        productDTO.setPrice(price);
//        productDTO.setProductId(productId);
//        productDTO.setStockQuantity(stockQuantity);
//        productDTO.setCategoryId(categoryId);
//        productDTO.setDescription(description);
//
//        return ResponseEntity.ok(productService.updateProduct(productDTO, imageFile));
//
//    }
//
//
//    @GetMapping("/all")
//    public ResponseEntity<Response> getAllProducts() {
//        return ResponseEntity.ok(productService.getAllProducts());
//    }
//
//    @GetMapping("/{id}")
//    public ResponseEntity<Response> getProductById(@PathVariable Long id) {
//        return ResponseEntity.ok(productService.getProductById(id));
//    }
//
//    @DeleteMapping("/delete/{id}")
//    public ResponseEntity<Response> deleteProduct(@PathVariable Long id) {
//        return ResponseEntity.ok(productService.deleteProduct(id));
//    }
//
//    @GetMapping("/search")
//    public ResponseEntity<Response> searchProduct(@RequestParam String input) {
//        return ResponseEntity.ok(productService.searchProduct(input));
//    }
//
//
//}
