package com.mngmt.inventorySystem.enums;

public enum TransactionType {
    PURCHASE, SALE, RETURN_TO_SUPPLIER
}
