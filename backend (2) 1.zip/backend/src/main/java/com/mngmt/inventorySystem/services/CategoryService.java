package com.mngmt.inventorySystem.services;

import com.mngmt.inventorySystem.dtos.CategoryDTO;
import com.mngmt.inventorySystem.dtos.Response;

public interface CategoryService {

    Response createCategory(CategoryDTO categoryDTO);

    Response getAllCategories();

    Response getCategoryById(Long id);

    Response updateCategory(Long id, CategoryDTO categoryDTO);

    Response deleteCategory(Long id);
}
