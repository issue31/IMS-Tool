package com.mngmt.inventorySystem.config;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Value("${ebay.api.base.url}")
    private String ebayApiBaseUrl;

    @Value("${ebay.api.token}")
    private String ebayApiToken;

    @Bean
    public WebClient webClient() {
        return WebClient.builder()
                .baseUrl(ebayApiBaseUrl)
                .defaultHeader("Authorization", "Bearer " + ebayApiToken)
                .build();
    }
}
