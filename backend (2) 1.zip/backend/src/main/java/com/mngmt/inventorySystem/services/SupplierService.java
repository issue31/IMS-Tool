package com.mngmt.inventorySystem.services;

import com.mngmt.inventorySystem.dtos.Response;
import com.mngmt.inventorySystem.dtos.SupplierDTO;

public interface SupplierService {

    Response addSupplier(SupplierDTO supplierDTO);

    Response updateSupplier(Long id, SupplierDTO supplierDTO);

    Response getAllSupplier();

    Response getSupplierById(Long id);

    Response deleteSupplier(Long id);

}
