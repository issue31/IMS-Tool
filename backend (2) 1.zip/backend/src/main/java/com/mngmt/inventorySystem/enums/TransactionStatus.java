package com.mngmt.inventorySystem.enums;

public enum TransactionStatus {
    PENDING, PROCESSING, COMPLETED, CANCELLED
}
