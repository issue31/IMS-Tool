package com.mngmt.inventorySystem.enums;

public enum UserRole {
    ADMIN, MANAGER
}
