//package com.mngmt.inventorySystem.controllers;
//
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.mngmt.inventorySystem.services.EbayService;
//
//@RestController
//@RequestMapping("/api/ebay")
//public class EbayController {
//
//    @Autowired
//    private EbayService ebayService;
//
//    @PostMapping("/migrate")
//    public ResponseEntity<String> migrateListing(@RequestBody Map<String, String> payload) {
//        String listingId = payload.get("listingId");
//        String sku = payload.get("sku");
//        String response = ebayService.migrateListing(listingId, sku);
//        return ResponseEntity.ok(response);
//    }
//}
