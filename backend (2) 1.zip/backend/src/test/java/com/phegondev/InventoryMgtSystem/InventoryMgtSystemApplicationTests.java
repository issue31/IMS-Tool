package com.phegondev.InventoryMgtSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryMgtSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
